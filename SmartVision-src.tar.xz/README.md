# Smart Vision 0.1 (prova de conceito)

Assistente visual silencioso para óculos inteligentes (Android 12+).
Toque nos óculos → pergunta → uma fotografia → resposta curta falada → silêncio.

> **Aviso de segurança.** Esta versão é um auxiliar de leitura e descrição.
> **Não detecta obstáculos, não guia a marcha e não substitui bengala, cão-guia
> ou acompanhante.** Ver `docs/ARQUITECTURA.md` §6 e §8.

## Instalar (sem Android Studio)
1. Criar um repositório privado no GitHub e carregar esta pasta.
2. Separador **Actions** → execução "Compilar APK" → descarregar o artefacto `SmartVision-debug` e usar `app-full-debug.apk` (inclui leitura de texto sem rede).
3. No Samsung, abrir o ficheiro `.apk` e autorizar a instalação (uma vez).
4. Abrir a Smart Vision → **Iniciar** → aceitar permissões.
5. Configurar o serviço de visão (endereço do servidor intermediário, ou chave pessoal para testes).

A instalação não altera o ChatGPT, a "ChatGPT Voice Bridge" nem a aplicação dos óculos; é removível sem efeitos residuais.

## Uso
| Gesto | Efeito |
|---|---|
| Toque na área táctil dos óculos (reprodução/pausa) | Acorda: sinal sonoro, depois fale |
| Novo toque enquanto responde | Interrompe e volta ao silêncio |
| Avançar faixa | Cala a resposta |
| Botão "Perguntar" na notificação | Alternativa sem óculos |

Frases reconhecidas localmente: *o que tenho à frente/esquerda/direita*, *lê isto*, *que produto é este / qual o preço*, *lê a ementa*, *que nota é esta*, *há obstáculos* (descrição apenas), *onde está a porta*, *onde estou*, *repete*, *pára*.

Com o telemóvel num suporte de peito, a câmara aponta na direcção do corpo.

## Estrutura
```
app/src/main/java/pt/palma/smartvision/
  core/       AssistantService (máquina de estados), Prefs
  glasses/    GlassesAdapter, GlassesRegistry, GenericAudio, XkOnePro, PhoneCamera, BleProbe
  voice/      SpeechInput (STT), SpeechOutput (TTS único), AudioRouting
  ai/         VisionClient (OpenAI Responses), LocalOcr (offline), Prompts, IntentRouter
  nav/        LocationHelper ("onde estou")
  wearables/  SensorBus (interfaces para sensores de obstáculos — Fase 6)
proxy/worker.js      servidor intermediário (a chave OpenAI nunca vai na APK)
docs/ARQUITECTURA.md análise, estado da arte, regulamentação, protocolo de ensaios
```

## Acrescentar outros óculos
Implementar `GlassesAdapter` (e `captureFrame()` se o modelo expuser câmara) e registá-lo em `GlassesRegistry`. Nada mais muda.
