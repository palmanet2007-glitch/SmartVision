# SMART VISION — Análise técnica, arquitectura e plano de desenvolvimento

**Versão:** 0.1 · **Data:** 26-09-2026 · **Âmbito:** aplicação Android de assistência visual para óculos inteligentes, com evolução para sistema de mobilidade autónoma.

Convenção usada ao longo do documento:
**[F]** facto verificado em fonte citada · **[I]** interpretação técnica · **[R]** recomendação profissional.

---

## 1. Síntese executiva

1. **[R] O objectivo operacional enunciado — vendar os olhos e sair sozinho, sem falhas, para um restaurante e um supermercado — não é atingível com segurança por nenhuma aplicação de telemóvel/óculos disponível à data, e não deve ser ensaiado sem acompanhante normovisual e sem bengala.** Não se trata de prudência genérica: é a conclusão directa do estado da arte (§2) e das limitações físicas do hardware (§3).
2. **[F]** O sistema de investigação mais avançado publicado este ano (Mobilio, Harvard, *Nature Biomedical Engineering*, Agosto de 2026) foi sempre avaliado **em conjunto com a bengala branca**, não em sua substituição; os próprios autores afirmam que o GPS de navegação corrente não tem precisão suficiente para uso seguro por pessoas cegas.
3. **[I]** A parte da tarefa em que a IA actual é **fiável e útil hoje** é a leitura e descrição pontual: ementas, rótulos, preços, notas de euro, identificação de produtos, descrição de uma cena. A parte **não fiável** é a mobilidade contínua: detecção de obstáculos, bordos de passeio, degraus, travessias, localização fina (< 3 m).
4. **[R]** Por isso a versão 0.1 entregue implementa **só o que é fiável**: assistente silencioso por defeito, activado por toque nos óculos, que ouve uma pergunta, capta uma imagem, responde numa ou duas frases e volta ao silêncio — com recurso offline para leitura de texto. A detecção de obstáculos fica **deliberadamente fora** da IA generativa e é preparada como camada separada, determinística e local (§5.5).
5. **[F]** Os XK one Pro **não expõem câmara a terceiros** por qualquer protocolo documentado. Nesta fase servem como **áudio + botão**; a imagem vem da câmara do telemóvel num suporte de peito. A arquitectura isola este facto num único adaptador, de modo que ligar outros óculos (Meta, etc.) não obriga a reescrever a aplicação.

---

## 2. Estado da arte verificado (Setembro de 2026)

| Sistema / tecnologia | O que faz | Limitação relevante |
|---|---|---|
| **Mobilio** (Harvard SEAS, 2026) [F] | Telemóvel com câmara, GPS, IMU e LiDAR; modelo de segmentação treinado em imagens do ponto de vista do peão; guia por sinais sonoros direccionais personalizados. Com bengala: percurso exterior ~13 % mais rápido e ~41 % menos contactos com obstáculos do que Google Maps + bengala; 14 participantes. | Ensaios com bengala; amostra pequena; ainda sem produto público. |
| **Be My Eyes / Be My AI em Ray-Ban Meta** [F] | Descrição visual e voluntários humanos, mãos livres, desde 2024. | Descrição a pedido, não guia de mobilidade. |
| **Meta Wearables Device Access Toolkit** [F] | SDK Android/iOS com acesso à câmara (vídeo e fotografia), microfones e altifalantes dos óculos Meta. | Em *developer preview*: permite desenvolver e testar, **não permite distribuir** a utilizadores finais. |
| **OpenAI Realtime API — gpt-realtime-2** (Maio 2026) [F] | Fala-para-fala de baixa latência, com entrada de **imagens** e chamadas de funções. | Aceita imagens, **não vídeo contínuo**; custo estimado por terceiros em ~0,15–0,20 USD/min de conversa. |
| **Gemini Live API** [F] | Voz bidireccional com **vídeo a 1 fotograma/s**, função e pesquisa. | 1 fps é manifestamente insuficiente para evitar obstáculos a passo de marcha. |

**[I] Leitura de conjunto.** Os modelos de linguagem com visão resolvem bem a pergunta *"o que é isto?"*, mas não resolvem *"vou bater em alguma coisa nos próximos dois segundos?"*. A segunda pergunta exige percepção contínua a ≥ 10–30 fps, latência abaixo de ~100 ms e comportamento determinístico — requisitos que um serviço na nuvem, com latências de segundos e respostas probabilísticas, não cumpre por construção. A própria documentação de terceiros sobre modelos de robótica da Google adverte para não usar o modelo como controlador de segurança física.

---

## 3. Hardware em ensaio — XK one Pro

### 3.1 Factos
- **[F]** Emparelha no Samsung como dispositivo de *chamadas e áudio* (perfis HFP/A2DP).
- **[F]** Segundo a embalagem, fotografia/vídeo são transferidos por **Wi-Fi** (JPEG/H.264); não foi encontrada documentação pública do protocolo nem SDK.
- **[F]** Existem vários produtos comercializados sob a designação "XK one Pro" (incluindo uma variante com marca HYUNDAI e anúncios contraditórios de 720p a "100 MP"), o que indica um produto genérico de OEM chinês com firmware potencialmente distinto entre lotes.
- **[F] Alerta:** a aplicação publicamente distribuída com o nome **"TubeBus"** (Vidus/Vidusoft) é um **descarregador de vídeos do YouTube**, não uma aplicação de óculos. Ou o QR do manual conduz a outra aplicação com nome semelhante, ou há coincidência de nomes.

### 3.2 Interpretação
- **[I]** O "botão IA" traseiro é muito provavelmente tratado no firmware e encaminhado para a aplicação do fabricante por um canal proprietário (BLE GATT), não por um evento Android normalizado. A mensagem "Disconnected" ouvida é compatível com o firmware a anunciar que **o serviço de IA da aplicação do fabricante** não está ligado — não o Bluetooth.
- **[I]** O toque na área táctil (reprodução/pausa) chega ao Android por AVRCP, que é normalizado. **É este o gesto que a Smart Vision usa para acordar** — funciona com qualquer óculos ou auricular Bluetooth.
- **[I]** A câmara Wi-Fi destes produtos funciona tipicamente como ponto de acesso próprio a que o telemóvel se liga para descarregar ficheiros. Mesmo que seja caracterizada, é previsível latência de vários segundos por fotografia — adequada a "lê isto", inadequada a mobilidade.

### 3.3 Recomendações
- **[R]** Não instalar APK "TubeBus" a partir de sites espelho (apkcombo, uptodown, etc.). Confirmar primeiro, a partir do QR do manual, **o nome exacto do pacote** e a loja de origem.
- **[R]** Caracterização do protocolo (Fase 1), por ordem e sem intervenção do utilizador final:
  1. **Diagnóstico BLE incluído na app** (botão "Diagnóstico dos óculos", 30 s, **só leitura**): enumera serviços GATT e regista notificações. Um único ensaio estruturado — premir cada botão uma vez, por ordem anotada — substitui as experiências aleatórias.
  2. **Tráfego Wi-Fi**: com a aplicação oficial, capturar o tráfego com PCAPdroid (captura por VPN local, sem *root*) para identificar o ponto de acesso, portas e formato (HTTP/RTSP/proprietário).
  3. Só então implementar `XkOneProAdapter.captureFrame()`.
- **[R]** Aceitar a hipótese, realista, de que os XK one Pro fiquem como **dispositivo de áudio e botão**. Para câmara nos óculos com SDK oficial, o caminho mais sólido é a linha Meta (DAT), ainda sem distribuição pública.

---

## 4. Requisitos (do *handoff* e do pedido)

| # | Requisito | Estado v0.1 |
|---|---|---|
| R1 | Silencioso por defeito; fala só a pedido | Implementado (máquina de estados, sem microfone/câmara/rede em repouso) |
| R2 | Activação por botão dos óculos | Implementado via toque AVRCP; botão "IA" dependente da Fase 1 |
| R3 | Palavra "Smart" | Preparado (remoção da palavra na frase); detector local por implementar (§5.3) |
| R4 | Resposta curta, uma só voz | Implementado (política de *prompt* + TTS único, sem sobreposição) |
| R5 | Visão: descrever, ler, produto, ementa, dinheiro, procurar | Implementado (câmara do telemóvel) |
| R6 | Funcionamento sem rede | Parcial: leitura de texto local (ML Kit) |
| R7 | Qualquer tipo de óculos | Implementado ao nível de arquitectura (adaptadores) |
| R8 | GPS com indicações precisas | "Onde estou?" implementado; **guia fino não viável com GPS** (§5.4) |
| R9 | Obstáculos | **Excluído da v0.1 por segurança**; interface preparada (§5.5) |
| R10 | Sem chaves na APK | Servidor intermediário incluído (`proxy/worker.js`) |

---

## 5. Arquitectura

```
┌──────────── Óculos (qualquer) ────────────┐   ┌─── Telemóvel ao peito ───┐
│ botão/toque (AVRCP) · altifalantes · mic  │   │ câmara · GPS · IMU       │
└──────────────┬────────────────────────────┘   └───────────┬──────────────┘
               │ GlassesAdapter (por modelo)                 │ FrameSource
┌──────────────▼─────────────────────────────────────────────▼──────────────┐
│ AssistantService (serviço em 1.º plano)                                   │
│  IDLE → LISTENING → THINKING → SPEAKING → IDLE                            │
│  IntentRouter (local, palavras-chave) → VisionClient | LocalOcr | GPS      │
│  SpeechInput (STT pt-PT) · SpeechOutput (TTS único) · AudioRouting         │
└──────────────┬────────────────────────────────────────────────────────────┘
               │ HTTPS
        proxy/worker.js ──► OpenAI Responses API (imagem + texto)

 [Futuro, separado e local]  ProximitySensor* ─► fusão ─► HapticOutput / áudio espacial
```

### 5.1 Camada de dispositivos
- `GlassesAdapter` declara capacidades (`audioOut`, `microphone`, `wakeButton`, `camera`, `stereoCamera`, `display`). O que um modelo não tem é suprido pelo telemóvel.
- `GlassesRegistry` escolhe automaticamente: perfil dedicado → qualquer áudio Bluetooth → só telemóvel. O utilizador não escolhe nada.
- **[I]** Encaminhamento dos botões: o Android envia as teclas multimédia à sessão de média que reproduziu áudio mais recentemente. A Smart Vision mantém uma `MediaSession` activa e reafirma-a depois de cada resposta falada; se o utilizador ouvir música noutra aplicação, esta pode "roubar" o toque até à próxima interacção. Limitação a validar em ensaio.

### 5.2 Visão
- Uma fotografia por pergunta, reduzida a 1024 px no lado maior (equilíbrio legibilidade/latência).
- Política de resposta (`Prompts.SYSTEM`): português europeu, 1–2 frases, referências egocêntricas ("à tua esquerda", "às 2 horas"), incerteza explícita, **proibição de declarar um caminho ou travessia "seguro"**, não identificação de terceiros.
- Modelo configurável (valor inicial `gpt-5-mini`, **a confirmar na documentação OpenAI em vigor** — os nomes mudam com frequência).
- **[R]** Evolução natural: migrar para a Realtime API (`gpt-realtime-2`) quando se quiser conversa contínua; mantém-se a regra de uma fotografia por pedido.

### 5.3 Voz e activação
- STT do sistema em pt-PT com preferência *offline*; TTS do sistema; sinais sonoros curtos em vez de frases de cortesia.
- Microfone dos óculos: o canal de voz Bluetooth (SCO) é aberto apenas durante a escuta. **[I]** O reconhecedor de fala do sistema nem sempre respeita o dispositivo de comunicação escolhido; se não respeitar, usa o microfone do telemóvel — aceitável na v0.1, a medir.
- Palavra "Smart": **[R]** detector local dedicado (Porcupine/Picovoice — licença comercial — ou openWakeWord), activo apenas quando o utilizador o ligar. Escuta permanente tem custo de bateria e de privacidade; o toque deve continuar a ser o método principal.

### 5.4 Localização e navegação
- **[F]** O GPS de telemóvel tem erro de vários metros, pior em "canyons" urbanos; os autores do Mobilio consideram-no insuficiente para guia seguro de pessoas cegas.
- **[R]** A v0.1 limita-se a "Onde estou?" (rua, número aproximado, precisão declarada). Guia ponto-a-ponto deve apoiar-se, quando for desenvolvido, em: (a) percurso por GPS para a escala da rua; (b) **percepção visual local** do passeio e das passadeiras (segmentação no dispositivo, como no Mobilio) para os últimos metros; (c) nunca instruir a atravessar — apenas descrever.

### 5.5 Obstáculos e sistema completo (Fase 6)
- **[R] Princípio de projecto:** alertas de colisão nunca dependem de rede nem de modelo generativo. Pipeline local, determinístico, com orçamento de latência < 100 ms do sensor ao sinal háptico.
- Interfaces já definidas em `wearables/SensorBus.kt`: `ProximitySensor` (calçado, bengala, peito, cabeça), `ProximityReading` (azimute, elevação — crucial para degraus e buracos —, distância, confiança) e `HapticOutput`.
- Sensores candidatos: ToF multizona (ex.: VL53L5CX, 8×8 zonas, alcance ~4 m) no calçado/peito; radar 60 GHz para objectos à altura da cabeça (a bengala não os detecta); câmara estereoscópica ou de profundidade nos óculos para mapa de profundidade denso.
- Elevação negativa (degraus descendentes, valas, bordos de cais) é o caso crítico e o mais difícil; deve ter validação própria.

---

## 6. Viabilidade por tarefa do cenário proposto

| Tarefa | Viabilidade v0.1 | Observação |
|---|---|---|
| Sair de casa e percorrer o passeio | **Não** sem bengala/guia | Obstáculos, desníveis, veículos |
| Atravessar ruas | **Nunca delegar** | Nem a v0.1 nem sistemas de investigação o fazem |
| Chegar à porta do restaurante | Parcial | GPS dá a rua; "procura a porta" dá indicação aproximada |
| Ler a ementa | **Sim** | Melhor caso de uso; pedir por secções |
| Pedir a refeição | Sim | Interacção humana normal |
| Encontrar corredor no supermercado | Parcial | Leitura de placas suspensas depende do enquadramento |
| Identificar produto/preço na prateleira | **Sim**, com várias tentativas | Preços em etiqueta de prateleira são o ponto fraco (letra pequena, reflexos) |
| Encher o carrinho sem colidir | **Não** | Pessoas e carrinhos em movimento |
| Pagar em numerário | Sim | Identificação de notas e moedas |
| Pagar com cartão em terminal táctil | **Não fiável** | PIN em ecrã táctil sem relevo; preferir *contactless* |
| Regressar a casa | Idêntico à ida | |

---

## 7. Enquadramento regulamentar (para a evolução para produto)

*Interpretação técnica; carece de validação jurídica especializada antes de qualquer colocação no mercado.*

- **[I] Dispositivo médico.** O Regulamento (UE) 2017/745 (MDR), art. 2.º, n.º 1, inclui na definição de dispositivo médico o *software* destinado à **compensação de uma deficiência**. Uma aplicação comercializada como auxiliar de mobilidade para pessoas cegas é, com elevada probabilidade, *software* dispositivo médico, classificado pela Regra 11 do Anexo VIII. Consequências: sistema de gestão da qualidade, gestão de risco (ISO 14971), avaliação clínica, marcação CE, eventualmente organismo notificado. Uma ferramenta de uso pessoal/experimental não colocada no mercado não está sujeita, mas **a intenção declarada determina o regime**.
- **[I] Regulamento da IA** (UE) 2024/1689: se a IA for componente de segurança de um produto abrangido pelo MDR sujeito a avaliação por terceiros, é **sistema de risco elevado** (art. 6.º, n.º 1, e Anexo I), com obrigações próprias de dados, registo, supervisão humana e robustez.
- **[I] RGPD.** As imagens captam terceiros (empregados, clientes). Uso pessoal beneficia da exclusão doméstica, mas o envio para um serviço na nuvem de um fornecedor deve ser coberto por minimização: uma imagem por pedido, sem gravação, sem retenção no servidor intermediário (já assim implementado), e informação clara ao utilizador. Para produto: avaliação de impacto (AIPD) e acordo de subcontratação com o fornecedor do modelo.
- **[R] Indicador luminoso.** O LED de captura dos óculos não deve ser desactivado: é o sinal de privacidade para terceiros e, em muitos produtos, exigência do fabricante.

---

## 8. Protocolo de ensaios faseado (segurança)

| Fase | Contexto | Condição de passagem |
|---|---|---|
| E0 | Em casa, **olhos abertos** | 20 perguntas-tipo: ≥ 90 % respostas correctas; tempo mediano toque→resposta registado |
| E1 | Em casa, olhos vendados, sentado | Leitura de 10 embalagens e 5 notas sem erro de valor |
| E2 | Restaurante, olhos vendados **à mesa**, acompanhante presente | Leitura de ementa e pedido autónomos |
| E3 | Supermercado, olhos vendados, **guia normovisual a um braço de distância**, bengala | Identificação de 15 produtos; zero decisões de marcha delegadas na app |
| E4 | Percursos pedonais | **Apenas após formação básica em orientação e mobilidade** (ex.: ACAPO) e com guia; a app usada só para leitura e "onde estou" |
| E5 | Mobilidade assistida por sensores | Só com a camada de obstáculos (§5.5) validada em circuito fechado |

**[R]** Uma pessoa normovisual com olhos vendados não tem a técnica de bengala nem os mapas mentais de uma pessoa cega treinada; o risco de queda ou atropelamento em E3–E4 sem guia é real. O valor destes ensaios está em serem **seguros e repetíveis**, com registo de falhas (a app mostra no ecrã o que ouviu e o que respondeu, para auditoria posterior).

---

## 9. Lacunas e pontos a confirmar

1. Nome exacto e origem da aplicação oficial dos XK one Pro (QR do manual).
2. Se o toque na área táctil chega ao Android como `PLAY_PAUSE` (confirmação no primeiro ensaio).
3. Protocolo Wi-Fi da câmara dos óculos (Fase 1).
4. Modelo OpenAI de visão recomendado à data da compilação e respectivo custo por imagem — medir em E0.
5. Latência real ponta-a-ponta em rede móvel (objectivo: < 3 s para leitura).
6. Compilação: o projecto não pôde ser compilado no ambiente em que foi redigido (sem acesso aos repositórios Android); a primeira execução do GitHub Actions servirá de verificação.

---

## 10. Fontes

- Harvard SEAS — *A Smartphone Navigation App for People with Blindness and Low Vision* (24-08-2026): https://seas.harvard.edu/news/smartphone-navigation-app-people-blindness-and-low-vision
- Liu, Slade et al., *Nature Biomedical Engineering* (2026), DOI 10.1038/s41551-026-01772-x
- Meta — Wearables Device Access Toolkit, FAQ: https://developers.meta.com/wearables/faq/
- Meta — repositório Android: https://github.com/facebook/meta-wearables-dat-android
- OpenAI — *Introducing gpt-realtime*: https://openai.com/index/introducing-gpt-realtime/
- OpenAI — Realtime conversations: https://platform.openai.com/docs/guides/realtime-conversations
- R. Walker — análise da Realtime API (custos e limitações, Jun. 2026): https://rywalker.com/research/openai-realtime-api
- Google — Gemini Live API (Vertex AI): https://docs.cloud.google.com/vertex-ai/generative-ai/docs/live-api
- Android Developers — Gemini Live API: https://developer.android.com/ai/gemini/live
- Be My Eyes (Ray-Ban Meta, 2024): https://en.wikipedia.org/wiki/Be_My_Eyes
- TubeBus (Vidus) — descarregador de vídeo: https://apkcombo.com/tubebus/com.vidus.tubebus/
- XK one Pro — fichas comerciais: https://www.amazon.com/One-Pro-Bluetooth-Translation-Interchangeable/dp/B0H6GDCTYT
- Regulamento (UE) 2017/745 (MDR); Regulamento (UE) 2024/1689 (IA); Regulamento (UE) 2016/679 (RGPD) — EUR-Lex.
