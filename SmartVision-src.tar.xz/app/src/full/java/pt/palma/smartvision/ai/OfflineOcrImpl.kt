package pt.palma.smartvision.ai

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * OCR local (ML Kit, modelo embebido): funciona SEM rede.
 * Usado como recurso quando o serviço de visão não responde, para que
 * "lê isto" nunca fique sem resposta num supermercado sem cobertura.
 */
class OfflineOcrImpl : OfflineOcr {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override suspend fun read(bitmap: Bitmap, maxChars: Int): String? =
        suspendCancellableCoroutine { cont ->
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result ->
                    // Ordena blocos por área (maior primeiro): títulos e preços costumam ser maiores.
                    val text = result.textBlocks
                        .sortedByDescending { b -> b.boundingBox?.let { it.width() * it.height() } ?: 0 }
                        .joinToString(". ") { it.text.replace('\n', ' ') }
                        .take(maxChars)
                    cont.resume(text.ifBlank { null })
                }
                .addOnFailureListener { cont.resume(null) }
        }
}
