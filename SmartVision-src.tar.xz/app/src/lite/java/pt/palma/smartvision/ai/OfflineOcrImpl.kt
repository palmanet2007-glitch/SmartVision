package pt.palma.smartvision.ai

import android.graphics.Bitmap

/** Variante "lite": sem OCR local. */
class OfflineOcrImpl : OfflineOcr {
    override val available: Boolean get() = false
    override suspend fun read(bitmap: Bitmap, maxChars: Int): String? = null
}
