package pt.palma.smartvision.ai

/**
 * Política operacional do assistente (baixa visão / mobilidade).
 * Redigida para respostas faladas: curtas, sem cortesias, com incerteza explícita.
 */
object Prompts {

    val SYSTEM = """
        És a Smart Vision, assistente visual de uma pessoa cega ou com baixa visão.
        Recebes UMA fotografia tirada agora, à altura do peito ou dos olhos, virada para a frente.
        Regras obrigatórias:
        1. Responde em português de Portugal, numa ou duas frases curtas, próprias para ouvir.
        2. Começa pela informação essencial. Sem introduções, sem "Claro", sem descrever o teu raciocínio.
        3. Usa referências egocêntricas: "à tua frente", "à esquerda", "à direita", "a cerca de dois passos", "às 2 horas".
        4. Distingue o que vês com clareza do que é incerto: diz "parece" ou "não consigo confirmar".
        5. Se a imagem estiver desfocada, escura ou não mostrar o que foi pedido, diz isso e sugere UMA acção (ex.: "Roda um pouco para a direita.").
        6. Nunca afirmes que um caminho, passadeira ou travessia está seguro. Descreve o que vês; a decisão é do utilizador.
        7. Ao ler texto: lê primeiro o essencial (nome do produto, preço, prato), só depois pormenores se pedidos.
        8. Não identifiques pessoas pelo nome nem inferes características sensíveis de terceiros.
    """.trimIndent()

    fun forIntent(intent: UserIntent, utterance: String): String = when (intent) {
        UserIntent.DESCRIBE -> "O que está à minha frente? Pedido original: \"$utterance\""
        UserIntent.READ -> "Lê o texto principal visível. Pedido original: \"$utterance\""
        UserIntent.PRODUCT -> "Identifica o produto: marca, tipo, quantidade e preço se visível. Pedido original: \"$utterance\""
        UserIntent.MENU -> "Isto é uma ementa. Diz quantas secções há e lê os nomes das secções; se o pedido for específico, responde só a isso. Pedido original: \"$utterance\""
        UserIntent.MONEY -> "Identifica notas ou moedas em euros e o total. Pedido original: \"$utterance\""
        UserIntent.OBSTACLE -> "Há obstáculos no caminho à minha frente, até cerca de 3 metros? Indica posição e distância aproximada. Pedido original: \"$utterance\""
        UserIntent.FIND -> "Procura na imagem o seguinte e indica a direcção: \"$utterance\""
        else -> utterance
    }
}

enum class UserIntent { DESCRIBE, READ, PRODUCT, MENU, MONEY, OBSTACLE, FIND, WHERE_AM_I, REPEAT, STOP, FREE }

/** Encaminhamento por palavras-chave — determinístico, local e sem latência. */
object IntentRouter {
    fun route(text: String): UserIntent {
        val t = text.lowercase()
        return when {
            listOf("pára", "para", "cala", "chega", "silêncio", "obrigado").any { t.startsWith(it) } -> UserIntent.STOP
            "repete" in t || "outra vez" in t -> UserIntent.REPEAT
            "onde estou" in t || "que rua" in t -> UserIntent.WHERE_AM_I
            "ementa" in t || "menu" in t || "pratos" in t -> UserIntent.MENU
            "preço" in t || "produto" in t || "embalagem" in t || "validade" in t -> UserIntent.PRODUCT
            "nota" in t || "moeda" in t || "troco" in t || "dinheiro" in t -> UserIntent.MONEY
            t.startsWith("lê") || "ler" in t || "o que diz" in t -> UserIntent.READ
            "obstáculo" in t || "caminho livre" in t || "posso avançar" in t -> UserIntent.OBSTACLE
            "onde está" in t || "procura" in t || "encontra" in t -> UserIntent.FIND
            "o que" in t && ("vejo" in t || "ver" in t || "frente" in t || "esquerda" in t || "direita" in t) -> UserIntent.DESCRIBE
            else -> UserIntent.FREE
        }
    }

    /** Remove a palavra de activação, se dita. */
    fun stripWakeWord(text: String): String =
        text.trim().replace(Regex("^(smart|esmarte|smarte)[,\\s]*", RegexOption.IGNORE_CASE), "")
}
