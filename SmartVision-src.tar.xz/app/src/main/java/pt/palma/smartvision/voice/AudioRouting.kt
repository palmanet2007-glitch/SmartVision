package pt.palma.smartvision.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.ToneGenerator

/**
 * Encaminhamento de áudio: uma única cadeia, controlada pela Smart Vision.
 *
 * - Fala (TTS) sai pelo dispositivo Bluetooth activo (A2DP) — os altifalantes dos óculos.
 * - Para ouvir o utilizador pelo microfone dos óculos é necessário abrir o canal
 *   de voz (HFP/SCO). Abre-se só durante a escuta e fecha-se logo a seguir,
 *   para não degradar o áudio nem gastar bateria.
 */
class AudioRouting(context: Context) {
    private val am: AudioManager = requireNotNull(context.getSystemService(AudioManager::class.java))
    private val tone = runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 60) }.getOrNull()

    @SuppressLint("MissingPermission")
    fun openGlassesMic(): Boolean {
        val sco = am.availableCommunicationDevices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
        } ?: return false
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        return am.setCommunicationDevice(sco)
    }

    fun closeGlassesMic() {
        am.clearCommunicationDevice()
        am.mode = AudioManager.MODE_NORMAL
    }

    /** Sinal sonoro curto: "estou a ouvir". Substitui qualquer frase de cortesia. */
    fun earconListening() { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 90) }

    /** Sinal duplo grave: "não percebi / falhou". */
    fun earconError() { tone?.startTone(ToneGenerator.TONE_PROP_NACK, 200) }
}
