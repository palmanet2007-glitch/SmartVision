package pt.palma.smartvision.ai

import android.graphics.Bitmap

/**
 * Leitura de texto sem rede. A implementação depende da variante de compilação:
 *  - "full": ML Kit (modelo embebido, funciona offline);
 *  - "lite": indisponível (APK mínima, sem bibliotecas Google).
 */
interface OfflineOcr {
    val available: Boolean get() = true
    suspend fun read(bitmap: Bitmap, maxChars: Int = 220): String?
}
