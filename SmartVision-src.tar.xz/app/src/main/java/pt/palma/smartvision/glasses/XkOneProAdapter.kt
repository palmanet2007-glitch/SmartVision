package pt.palma.smartvision.glasses

import android.content.Context

/**
 * XK one Pro — perfil de integração provisório.
 *
 * Estado verificado (26-09-2026):
 *  - Emparelha como dispositivo Bluetooth de chamadas e áudio (HFP/A2DP).
 *  - Fotografia/vídeo transferidos por Wi-Fi (segundo a embalagem), protocolo
 *    proprietário NÃO documentado publicamente; sem SDK conhecido.
 *  - O "botão IA" traseiro pode ser tratado no firmware e não chegar ao Android.
 *
 * Consequência: nesta versão o XK one Pro é usado como ÁUDIO + BOTÃO (via
 * AVRCP, herdado do adaptador genérico). A imagem vem da câmara do telemóvel.
 * Quando o protocolo Wi-Fi for caracterizado (ver BleProbe e docs/ARQUITECTURA.md
 * §6), implementar captureFrame() aqui sem alterar o resto da aplicação.
 */
class XkOneProAdapter(context: Context, address: String, name: String) :
    GenericAudioGlassesAdapter(context, address, name) {

    override val capabilities: Capabilities = Capabilities(
        audioOut = true, microphone = true, wakeButton = true,
        camera = false, // passa a true quando o canal Wi-Fi estiver implementado
    )

    companion object {
        fun matches(name: String?): Boolean =
            name?.replace(" ", "")?.contains("XKone", ignoreCase = true) == true
    }
}
