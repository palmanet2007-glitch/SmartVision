package pt.palma.smartvision.wearables

import kotlinx.coroutines.flow.Flow

/**
 * Barramento de sensores para a fase de sistema completo (Fase 6).
 *
 * Qualquer sensor de proximidade (calçado, bengala, cinto, óculos estereoscópicos)
 * publica leituras normalizadas; a camada de alertas funde-as e decide o feedback
 * (háptico / áudio espacial). Mantido fora da IA generativa por princípio:
 * alertas de colisão têm de ser determinísticos, locais e com latência < 100 ms.
 */
interface ProximitySensor {
    val id: String
    val mounting: Mounting
    val readings: Flow<ProximityReading>
}

enum class Mounting { SHOE_LEFT, SHOE_RIGHT, CANE, CHEST, HEAD, WRIST }

data class ProximityReading(
    val timestampNanos: Long,
    /** Direcção relativa ao corpo, em graus (0 = frente, negativo = esquerda). */
    val bearingDeg: Float,
    /** Elevação relativa (negativo = abaixo do plano do sensor: degraus, buracos). */
    val elevationDeg: Float,
    val distanceM: Float,
    val confidence: Float,
)

interface HapticOutput {
    fun pulse(bearingDeg: Float, intensity: Float)
}
