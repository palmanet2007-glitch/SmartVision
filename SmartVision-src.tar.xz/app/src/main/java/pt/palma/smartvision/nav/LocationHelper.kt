package pt.palma.smartvision.nav

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.coroutines.resume

/**
 * "Onde estou?" — posição actual e morada aproximada.
 *
 * Nota técnica: o GPS de um telemóvel em meio urbano tem erro típico de vários
 * metros (pior junto a fachadas altas). Serve para orientação geral (rua, quarteirão),
 * NUNCA para localizar uma passadeira, uma porta ou o bordo de um passeio.
 */
class LocationHelper(private val context: Context) {

    @SuppressLint("MissingPermission")
    suspend fun current(): Location? {
        val lm = context.getSystemService(LocationManager::class.java) ?: return null
        return withTimeoutOrNull(8_000) {
            suspendCancellableCoroutine<Location?> { cont ->
                lm.getCurrentLocation(
                    LocationManager.FUSED_PROVIDER, null, Executors.newSingleThreadExecutor(),
                ) { loc -> if (cont.isActive) cont.resume(loc) }
            }
        } ?: lm.getLastKnownLocation(LocationManager.FUSED_PROVIDER)
    }

    suspend fun describe(): String = withContext(Dispatchers.IO) {
        val loc = current() ?: return@withContext "Não consigo obter a localização."
        val acc = if (loc.hasAccuracy()) " Precisão de cerca de ${loc.accuracy.toInt()} metros." else ""
        @Suppress("DEPRECATION")
        val addr = runCatching {
            Geocoder(context, Locale.forLanguageTag("pt-PT"))
                .getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
        }.getOrNull()
        if (addr == null) "Localização obtida, sem morada disponível.$acc"
        else listOfNotNull(addr.thoroughfare, addr.subThoroughfare, addr.locality)
            .joinToString(", ").ifBlank { addr.getAddressLine(0) } + ".$acc"
    }
}
