package pt.palma.smartvision.glasses

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Câmara traseira do telemóvel (Camera2, API nativa), usada com o telemóvel num
 * suporte de peito.
 *
 * A câmara só é aberta durante a captura e fechada logo a seguir: em repouso
 * não há câmara activa (privacidade e bateria). Antes da fotografia corre uma
 * pré-visualização invisível de ~0,6 s para estabilizar exposição e focagem.
 */
class PhoneCameraSource(
    private val context: Context,
    private val maxSide: Int = 1024,
) : FrameSource {

    private val manager = requireNotNull(context.getSystemService(CameraManager::class.java))

    override suspend fun start(): Boolean = backCameraId() != null
    override fun stop() {}

    override suspend fun capture(): Bitmap? = withTimeoutOrNull(6_000) { captureInternal() }

    private fun backCameraId(): String? = runCatching {
        manager.cameraIdList.firstOrNull {
            manager.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK
        }
    }.getOrNull()

    @SuppressLint("MissingPermission")
    private suspend fun captureInternal(): Bitmap? {
        val id = backCameraId() ?: return null
        val chars = manager.getCameraCharacteristics(id)
        val sensorOrientation = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val jpegSize = chooseJpegSize(chars)

        val thread = HandlerThread("sv-camera").apply { start() }
        val handler = Handler(thread.looper)
        val jpegReader = ImageReader.newInstance(jpegSize.width, jpegSize.height, ImageFormat.JPEG, 2)
        val previewReader = ImageReader.newInstance(640, 480, ImageFormat.YUV_420_888, 3)
        previewReader.setOnImageAvailableListener({ r -> r.acquireLatestImage()?.close() }, handler)

        var device: CameraDevice? = null
        var session: CameraCaptureSession? = null
        try {
            device = suspendCancellableCoroutine<CameraDevice?> { cont ->
                manager.openCamera(id, object : CameraDevice.StateCallback() {
                    override fun onOpened(camera: CameraDevice) { if (cont.isActive) cont.resume(camera) else camera.close() }
                    override fun onDisconnected(camera: CameraDevice) { camera.close(); if (cont.isActive) cont.resume(null) }
                    override fun onError(camera: CameraDevice, error: Int) { camera.close(); if (cont.isActive) cont.resume(null) }
                }, handler)
            } ?: return null
            val dev = device

            session = suspendCancellableCoroutine<CameraCaptureSession?> { cont ->
                val outputs = listOf(OutputConfiguration(previewReader.surface), OutputConfiguration(jpegReader.surface))
                val config = SessionConfiguration(
                    SessionConfiguration.SESSION_REGULAR, outputs, { handler.post(it) },
                    object : CameraCaptureSession.StateCallback() {
                        override fun onConfigured(s: CameraCaptureSession) { if (cont.isActive) cont.resume(s) }
                        override fun onConfigureFailed(s: CameraCaptureSession) { if (cont.isActive) cont.resume(null) }
                    },
                )
                dev.createCaptureSession(config)
            } ?: return null
            val sess = session

            // Pré-visualização invisível para convergência de exposição/focagem.
            val preview = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(previewReader.surface)
                set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            }.build()
            sess.setRepeatingRequest(preview, null, handler)
            delay(600)

            val bytes = suspendCancellableCoroutine<ByteArray?> { cont ->
                jpegReader.setOnImageAvailableListener({ r ->
                    val img = r.acquireLatestImage()
                    val data = img?.let {
                        val buf = it.planes[0].buffer
                        ByteArray(buf.remaining()).also { b -> buf.get(b) }
                    }
                    img?.close()
                    if (cont.isActive) cont.resume(data)
                }, handler)
                val still = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                    addTarget(jpegReader.surface)
                    set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                    set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                    set(CaptureRequest.JPEG_QUALITY, 90.toByte())
                }.build()
                sess.capture(still, null, handler)
            } ?: return null

            return withContext(Dispatchers.Default) { decode(bytes, sensorOrientation) }
        } catch (e: Exception) {
            return null
        } finally {
            runCatching { session?.close() }
            runCatching { device?.close() }
            jpegReader.close()
            previewReader.close()
            thread.quitSafely()
        }
    }

    /** Menor resolução JPEG com lado maior ≥ 1600 px (boa leitura de rótulos, ficheiro leve). */
    private fun chooseJpegSize(chars: CameraCharacteristics): Size {
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val sizes = map?.getOutputSizes(ImageFormat.JPEG)?.toList().orEmpty()
        return sizes.filter { maxOf(it.width, it.height) >= 1600 }
            .minByOrNull { it.width.toLong() * it.height }
            ?: sizes.maxByOrNull { it.width.toLong() * it.height }
            ?: Size(1920, 1080)
    }

    private fun decode(bytes: ByteArray, rotation: Int): Bitmap? {
        val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val scale = maxSide.toFloat() / maxOf(raw.width, raw.height)
        val m = Matrix().apply {
            if (scale < 1f) postScale(scale, scale)
            postRotate(rotation.toFloat()) // telemóvel na vertical, câmara traseira
        }
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    }
}
