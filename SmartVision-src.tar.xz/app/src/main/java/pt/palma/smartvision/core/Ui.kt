package pt.palma.smartvision.core

import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executor

/** Despachante da thread principal, sem depender de bibliotecas AndroidX. */
object Ui {
    private val handler = Handler(Looper.getMainLooper())
    val executor: Executor = Executor { handler.post(it) }
    val Main: CoroutineDispatcher = executor.asCoroutineDispatcher()
}
