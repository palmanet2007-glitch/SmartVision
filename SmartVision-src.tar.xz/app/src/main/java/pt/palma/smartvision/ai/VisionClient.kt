package pt.palma.smartvision.ai

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente do serviço de visão (OpenAI Responses API, entrada imagem+texto).
 *
 * Dois modos:
 *  - PROXY (recomendado): a app fala com um servidor próprio que guarda a chave
 *    e reencaminha o pedido. Nenhuma credencial fica na APK.
 *  - DIRECTO (só prova de conceito pessoal): chave introduzida pelo utilizador,
 *    guardada no armazenamento privado da aplicação.
 *
 * O modelo é configurável porque os nomes de modelos mudam com frequência.
 */
class VisionClient(
    private val apiKey: String?,
    private val proxyUrl: String?,
    private val model: String,
) {
    val isConfigured: Boolean get() = !proxyUrl.isNullOrBlank() || !apiKey.isNullOrBlank()

    suspend fun ask(question: String, image: Bitmap?): String = withContext(Dispatchers.IO) {
        val content = JSONArray().put(JSONObject().put("type", "input_text").put("text", question))
        if (image != null) {
            content.put(
                JSONObject().put("type", "input_image")
                    .put("image_url", "data:image/jpeg;base64," + image.toBase64Jpeg())
                    .put("detail", "high"),
            )
        }
        val body = JSONObject()
            .put("model", model)
            .put("instructions", Prompts.SYSTEM)
            .put("input", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            .put("max_output_tokens", 800)
        if (model.startsWith("gpt-5") || model.startsWith("o")) {
            body.put("reasoning", JSONObject().put("effort", "low"))
        }

        val url = if (!proxyUrl.isNullOrBlank()) proxyUrl else "https://api.openai.com/v1/responses"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 5_000
            readTimeout = 20_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (proxyUrl.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) throw VisionException("HTTP $code")
            val txt = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            extractText(JSONObject(txt)) ?: throw VisionException("Resposta vazia")
        } finally {
            conn.disconnect()
        }
    }

    /** Extrai o texto de saída do formato Responses API. */
    private fun extractText(json: JSONObject): String? {
        json.optString("output_text").takeIf { it.isNotBlank() }?.let { return it }
        val output = json.optJSONArray("output") ?: return null
        val sb = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.getJSONObject(i)
            if (item.optString("type") != "message") continue
            val parts = item.optJSONArray("content") ?: continue
            for (j in 0 until parts.length()) {
                val p = parts.getJSONObject(j)
                if (p.optString("type") == "output_text") sb.append(p.optString("text"))
            }
        }
        return sb.toString().trim().ifBlank { null }
    }

    private fun Bitmap.toBase64Jpeg(): String {
        val bos = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, 80, bos)
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }
}

class VisionException(msg: String) : Exception(msg)
