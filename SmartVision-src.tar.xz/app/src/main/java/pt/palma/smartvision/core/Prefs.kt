package pt.palma.smartvision.core

import android.content.Context

/** Definições persistentes (armazenamento privado da aplicação). */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("smartvision", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "").orEmpty()
        set(v) = sp.edit().putString("apiKey", v.trim()).apply()

    var proxyUrl: String
        get() = sp.getString("proxyUrl", "").orEmpty()
        set(v) = sp.edit().putString("proxyUrl", v.trim()).apply()

    var model: String
        get() = sp.getString("model", DEFAULT_MODEL).orEmpty().ifBlank { DEFAULT_MODEL }
        set(v) = sp.edit().putString("model", v.trim()).apply()

    var speechRate: Float
        get() = sp.getFloat("rate", 1.15f)
        set(v) = sp.edit().putFloat("rate", v).apply()

    companion object {
        /** Verificar na documentação OpenAI o modelo de visão rápido em vigor. */
        const val DEFAULT_MODEL = "gpt-5-mini"
    }
}
