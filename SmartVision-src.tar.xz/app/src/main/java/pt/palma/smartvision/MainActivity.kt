package pt.palma.smartvision

import android.Manifest
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.app.Activity
import android.content.pm.PackageManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import pt.palma.smartvision.core.Ui
import kotlinx.coroutines.launch
import pt.palma.smartvision.core.AssistantService
import pt.palma.smartvision.core.Prefs
import pt.palma.smartvision.glasses.BleProbe
import pt.palma.smartvision.glasses.GlassesRegistry
import pt.palma.smartvision.glasses.XkOneProAdapter

/**
 * Ecrã único: arrancar/parar, perguntar, configurar, diagnosticar.
 * Uso diário: arrancar uma vez; depois tudo acontece pelos óculos.
 */
class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Ui.Main)

    private lateinit var prefs: Prefs
    private lateinit var status: TextView

    private val permissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.POST_NOTIFICATIONS,
    )
    override fun onRequestPermissionsResult(requestCode: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, perms, results)
        onStartRequested()
    }

    private fun onStartRequested() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            AssistantService.start(this)
        } else {
            status.text = "A Smart Vision precisa do microfone para funcionar."
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 64)
        }
        fun big(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            minHeight = 180
            setOnClickListener { onClick() }
            root.addView(this, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 24 })
        }
        fun field(hint: String, value: String, secret: Boolean = false) = EditText(this).apply {
            this.hint = hint
            setText(value)
            contentDescription = hint
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            root.addView(this, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = 16 })
        }

        status = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            gravity = Gravity.START
            accessibilityLiveRegion = android.view.View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(status)

        big("Iniciar Smart Vision") {
            val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isEmpty()) onStartRequested() else requestPermissions(missing.toTypedArray(), 1)
        }
        big("Perguntar agora") { AssistantService.wake(this) }
        big("Parar Smart Vision") { AssistantService.stop(this) }

        root.addView(TextView(this).apply {
            text = "\nConfiguração do serviço de visão"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        })
        val proxy = field("Endereço do servidor intermediário (recomendado)", prefs.proxyUrl)
        val key = field("Chave OpenAI (só para testes pessoais)", prefs.apiKey, secret = true)
        val model = field("Modelo", prefs.model)
        big("Guardar configuração") {
            prefs.proxyUrl = proxy.text.toString()
            prefs.apiKey = key.text.toString()
            prefs.model = model.text.toString()
            status.text = "Configuração guardada."
        }

        root.addView(TextView(this).apply {
            text = "\nDiagnóstico (técnico)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        })
        big("Diagnóstico dos óculos (30 s, só leitura)") { runProbe() }

        setContentView(ScrollView(this).apply { addView(root) })

        scope.launch {
            combine(AssistantService.state, AssistantService.lastHeard, AssistantService.lastAnswer) { s, h, a ->
                val g = GlassesRegistry.detect(this@MainActivity)?.displayName ?: "nenhuns óculos detectados"
                "Estado: ${label(s)}\nDispositivo: $g" +
                    (if (h.isNotBlank()) "\nOuvi: $h" else "") +
                    (if (a.isNotBlank()) "\nResposta: $a" else "")
            }.collect { status.text = it }
        }
    }

    private fun label(s: AssistantService.State) = when (s) {
        AssistantService.State.IDLE -> "em silêncio"
        AssistantService.State.LISTENING -> "a ouvir"
        AssistantService.State.THINKING -> "a analisar"
        AssistantService.State.SPEAKING -> "a responder"
    }

    private fun runProbe() {
        val probe = BleProbe(this)
        val dev = runCatching { probe.bondedDevices() }.getOrDefault(emptyList())
            .firstOrNull { XkOneProAdapter.matches(it.name) }
        if (dev == null) {
            status.text = "XK one Pro não encontrado entre os dispositivos emparelhados."
            return
        }
        status.text = "A observar ${dev.name} durante 30 s. Prima cada botão uma vez, com pausas."
        scope.launch {
            val file = probe.probe(dev)
            status.text = "Registo gravado em:\n${file.absolutePath}\n(enviar ao programador)"
        }
    }
}
