package pt.palma.smartvision.glasses

import android.content.Context
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.content.Intent
import android.view.KeyEvent
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow

/**
 * Adaptador genérico para QUALQUER óculos/auricular Bluetooth com áudio.
 *
 * Wake: os toques na área táctil ou botão de reprodução chegam ao Android
 * como teclas multimédia normalizadas (AVRCP). Mantendo uma MediaSession
 * activa, a Smart Vision recebe-as sem depender da aplicação do fabricante.
 *
 *   PLAY / PAUSE / PLAY_PAUSE / HEADSETHOOK  -> Wake
 *   NEXT                                     -> Cancel (cala a resposta)
 *
 * Limitação conhecida: botões tratados apenas no firmware (ex.: o "botão IA"
 * de muitos óculos) podem nunca chegar ao Android. Nesse caso usa-se o toque.
 */
open class GenericAudioGlassesAdapter(
    private val context: Context,
    override val id: String,
    override val displayName: String,
) : GlassesAdapter {

    override val capabilities: Capabilities = Capabilities(
        audioOut = true, microphone = true, wakeButton = true, camera = false,
    )

    private val _events = MutableSharedFlow<GlassesEvent>(
        extraBufferCapacity = 8, onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    override val events: SharedFlow<GlassesEvent> = _events

    private var session: MediaSession? = null

    override suspend fun connect(): Boolean {
        if (session != null) return true
        session = MediaSession(context, "SmartVision").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    @Suppress("DEPRECATION")
                    val ev = mediaButtonIntent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
                        ?: return false
                    if (ev.action != KeyEvent.ACTION_UP) return true
                    when (ev.keyCode) {
                        KeyEvent.KEYCODE_MEDIA_PLAY,
                        KeyEvent.KEYCODE_MEDIA_PAUSE,
                        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                        KeyEvent.KEYCODE_HEADSETHOOK -> _events.tryEmit(GlassesEvent.Wake)
                        KeyEvent.KEYCODE_MEDIA_NEXT,
                        KeyEvent.KEYCODE_MEDIA_STOP -> _events.tryEmit(GlassesEvent.Cancel)
                        else -> return false
                    }
                    return true
                }
            })
            // Estado "a reproduzir" torna esta sessão a destinatária preferencial
            // dos botões multimédia (regra de encaminhamento do Android).
            setPlaybackState(
                PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE)
                    .setState(PlaybackState.STATE_PLAYING, 0, 0f)
                    .build(),
            )
            isActive = true
        }
        _events.tryEmit(GlassesEvent.Connection(true))
        return true
    }

    /** Reafirma a prioridade da sessão (chamar após o TTS ter reproduzido áudio). */
    fun reclaimMediaButtons() {
        session?.isActive = true
    }

    override fun disconnect() {
        session?.release()
        session = null
        _events.tryEmit(GlassesEvent.Connection(false))
    }
}
