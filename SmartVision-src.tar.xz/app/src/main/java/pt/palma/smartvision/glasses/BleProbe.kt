package pt.palma.smartvision.glasses

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Sonda BLE de diagnóstico — SÓ LEITURA.
 *
 * Liga-se ao dispositivo por GATT, enumera serviços/características e subscreve
 * notificações durante uma janela de observação. Tudo o que chega é escrito num
 * ficheiro de registo para caracterizar o protocolo proprietário (Fase 1),
 * sem escrever nada no dispositivo nem alterar a sua configuração.
 */
class BleProbe(private val context: Context) {

    @SuppressLint("MissingPermission")
    suspend fun probe(device: BluetoothDevice, observeMs: Long = 30_000): File {
        val out = File(context.getExternalFilesDir(null), "ble_probe_${stamp()}.txt")
        val log = StringBuilder()
        fun w(s: String) { synchronized(log) { log.appendLine("${stamp()}  $s") } }

        w("Dispositivo: ${device.name} / ${device.address} / tipo=${device.type}")
        val discovered = CompletableDeferred<BluetoothGatt?>()

        val cb = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                w("Estado GATT: status=$status newState=$newState")
                if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
                else if (newState == BluetoothProfile.STATE_DISCONNECTED) discovered.complete(null)
            }
            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                w("Serviços descobertos (status=$status)")
                g.services.forEach { s ->
                    w("SERVIÇO ${s.uuid}")
                    s.characteristics.forEach { c ->
                        w("   CARACT ${c.uuid} props=${props(c.properties)}")
                    }
                }
                discovered.complete(g)
            }
            @Deprecated("API < 33")
            override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
                @Suppress("DEPRECATION")
                w("NOTIF ${c.uuid} = ${c.value?.toHex()}")
            }
            override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
                w("NOTIF ${c.uuid} = ${value.toHex()}")
            }
        }

        val gatt = device.connectGatt(context, false, cb, BluetoothDevice.TRANSPORT_LE)
        val g = withTimeoutOrNull(15_000) { discovered.await() }
        if (g == null) {
            w("Sem ligação GATT (o dispositivo pode expor apenas Bluetooth clássico).")
        } else {
            // Subscreve notificações (apenas leitura) para observar eventos de botões.
            g.services.flatMap { it.characteristics }
                .filter { it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 }
                .forEach { g.setCharacteristicNotification(it, true) }
            w("A observar durante ${observeMs / 1000}s — premir cada botão UMA vez, com pausas, anotando a ordem.")
            kotlinx.coroutines.delay(observeMs)
        }
        gatt.disconnect(); gatt.close()
        out.writeText(log.toString())
        return out
    }

    @SuppressLint("MissingPermission")
    fun bondedDevices(): List<BluetoothDevice> =
        context.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList().orEmpty()

    private fun props(p: Int) = buildList {
        if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) add("R")
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) add("W")
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) add("Wnr")
        if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) add("N")
        if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) add("I")
    }.joinToString("|")

    private fun ByteArray.toHex() = joinToString(" ") { "%02X".format(it) }
    private fun stamp() = SimpleDateFormat("HH:mm:ss.SSS", Locale.ROOT).format(Date())
}
