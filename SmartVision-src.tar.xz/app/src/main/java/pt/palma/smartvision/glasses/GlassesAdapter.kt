package pt.palma.smartvision.glasses

import android.graphics.Bitmap
import kotlinx.coroutines.flow.Flow

/**
 * Contrato único entre a Smart Vision e qualquer par de óculos (ou outra fonte).
 *
 * Princípio: a aplicação nunca depende de um modelo concreto. Cada modelo
 * declara o que consegue fazer ([Capabilities]); o que não consegue é
 * assegurado por um substituto (tipicamente a câmara do telemóvel).
 */
interface GlassesAdapter {
    val id: String
    val displayName: String
    val capabilities: Capabilities

    /** Eventos de activação vindos do hardware (botão, toque, gesto). */
    val events: Flow<GlassesEvent>

    suspend fun connect(): Boolean
    fun disconnect()

    /** Captura uma imagem. Devolve null se o modelo não expõe câmara. */
    suspend fun captureFrame(): Bitmap? = null
}

data class Capabilities(
    val audioOut: Boolean,
    val microphone: Boolean,
    val wakeButton: Boolean,
    val camera: Boolean,
    val stereoCamera: Boolean = false,
    val display: Boolean = false,
)

sealed interface GlassesEvent {
    /** Pedido de atenção do utilizador (botão/toque). */
    data object Wake : GlassesEvent
    /** Interromper a fala em curso. */
    data object Cancel : GlassesEvent
    data class Connection(val connected: Boolean) : GlassesEvent
}

/** Fonte de imagem independente dos óculos (telemóvel ao peito, câmara externa, etc.). */
interface FrameSource {
    suspend fun start(): Boolean
    suspend fun capture(): Bitmap?
    fun stop()
}
