package pt.palma.smartvision.glasses

import android.annotation.SuppressLint
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothManager
import android.content.Context

/**
 * Selecciona automaticamente o adaptador adequado entre os dispositivos
 * emparelhados, sem intervenção do utilizador. Ordem de preferência:
 *   1. Modelos com perfil dedicado (XK one Pro, futuros Meta/Brilliant/etc.)
 *   2. Qualquer dispositivo de áudio Bluetooth (óculos ou auricular)
 *   3. Nenhum — funciona só com o telemóvel (altifalante + botão no ecrã)
 */
object GlassesRegistry {

    @SuppressLint("MissingPermission")
    fun detect(context: Context): GlassesAdapter? {
        val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter ?: return null
        val bonded = runCatching { adapter.bondedDevices.toList() }.getOrDefault(emptyList())

        bonded.firstOrNull { XkOneProAdapter.matches(it.name) }?.let {
            return XkOneProAdapter(context, it.address, it.name ?: "XK one Pro")
        }
        // Espaço para perfis futuros:
        // MetaDatAdapter (Meta Wearables Device Access Toolkit), FrameAdapter, ...

        bonded.firstOrNull {
            it.bluetoothClass?.majorDeviceClass == BluetoothClass.Device.Major.AUDIO_VIDEO
        }?.let {
            return GenericAudioGlassesAdapter(context, it.address, it.name ?: "Áudio Bluetooth")
        }
        return null
    }
}
