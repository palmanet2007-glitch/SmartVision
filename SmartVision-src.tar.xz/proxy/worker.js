/**
 * Servidor intermediário mínimo (Cloudflare Worker) para a Smart Vision.
 *
 * Finalidade: a chave OpenAI fica AQUI, nunca na APK.
 * Configuração:
 *   wrangler secret put OPENAI_API_KEY
 *   wrangler secret put ACCESS_TOKEN      (cadeia longa aleatória)
 * Na app, "Endereço do servidor intermediário" = https://<worker>.workers.dev/<ACCESS_TOKEN>
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method !== "POST" || url.pathname !== `/${env.ACCESS_TOKEN}`) {
      return new Response("Not found", { status: 404 });
    }
    const body = await request.text();
    if (body.length > 3_000_000) return new Response("Too large", { status: 413 });

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body,
    });
    // Não se registam imagens nem texto: apenas o código de estado.
    console.log("smartvision", upstream.status);
    return new Response(upstream.body, {
      status: upstream.status,
      headers: { "Content-Type": "application/json" },
    });
  },
};
