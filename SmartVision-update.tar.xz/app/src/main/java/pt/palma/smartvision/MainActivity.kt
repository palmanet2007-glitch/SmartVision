package pt.palma.smartvision

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import pt.palma.smartvision.core.AssistantService
import pt.palma.smartvision.core.Prefs
import pt.palma.smartvision.core.Ui
import pt.palma.smartvision.glasses.BleProbe
import pt.palma.smartvision.glasses.GlassesRegistry
import pt.palma.smartvision.glasses.XkOneProAdapter

/**
 * Ecrã único, de alto contraste, pensado para baixa visão:
 * um botão grande para perguntar, estado sempre visível, configuração recolhida.
 * Todo o texto relevante é anunciado pelo TalkBack.
 */
class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Ui.Main)
    private lateinit var prefs: Prefs

    // Paleta (contraste elevado)
    private val bg = Color.parseColor("#0E1116")
    private val card = Color.parseColor("#1A1F27")
    private val stroke = Color.parseColor("#2C3440")
    private val fg = Color.parseColor("#F2F4F7")
    private val muted = Color.parseColor("#9AA4B2")
    private val accent = Color.parseColor("#FFC83D")
    private val accentText = Color.parseColor("#1A1300")

    private lateinit var stateDot: View
    private lateinit var stateLabel: TextView
    private lateinit var askButton: Button
    private lateinit var askHint: TextView
    private lateinit var startStop: Button
    private lateinit var deviceText: TextView
    private lateinit var logText: TextView
    private lateinit var settingsBody: LinearLayout
    private lateinit var answerText: TextView

    private val permissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.POST_NOTIFICATIONS,
    )

    // ---------- utilitários de desenho ----------
    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun rounded(fill: Int, radiusDp: Int, strokeColor: Int? = null) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radiusDp).toFloat()
        if (strokeColor != null) setStroke(dp(1), strokeColor)
    }

    private fun ripple(content: GradientDrawable, rippleColor: Int = Color.argb(60, 255, 255, 255)) =
        RippleDrawable(ColorStateList.valueOf(rippleColor), content, null)

    private fun label(t: String, size: Float, color: Int = fg, bold: Boolean = false) = TextView(this).apply {
        this.text = t
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setLineSpacing(0f, 1.15f)
    }

    private fun cardView(title: String, body: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(card, 20, stroke)
        setPadding(dp(18), dp(16), dp(18), dp(18))
        addView(label(title.uppercase(), 12f, muted, bold = true).apply { letterSpacing = 0.08f })
        addView(body, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
    }

    private fun secondaryButton(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(fg)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        background = ripple(rounded(card, 16, stroke))
        stateListAnimator = null
        minHeight = dp(56)
        setOnClickListener { onClick() }
    }

    private fun field(hint: String, value: String, secret: Boolean = false) = EditText(this).apply {
        this.hint = hint
        setText(value)
        contentDescription = hint
        setTextColor(fg)
        setHintTextColor(muted)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        background = rounded(bg, 12, stroke)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        isSingleLine = true
        inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
    }

    private fun LinearLayout.gap(v: Int) = addView(View(context), LinearLayout.LayoutParams(1, dp(v)))

    // ---------- ecrã ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(32))
            setBackgroundColor(bg)
        }

        // Cabeçalho
        root.addView(label("Smart Vision", 30f, bold = true))
        root.addView(label("Assistente visual silencioso", 15f, muted))
        root.gap(18)

        // Estado
        val stateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(card, 50, stroke)
            setPadding(dp(14), dp(8), dp(18), dp(8))
        }
        stateDot = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(muted) } }
        stateLabel = label("Parada", 15f, bold = true).apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        stateRow.addView(stateDot, LinearLayout.LayoutParams(dp(12), dp(12)))
        stateRow.addView(stateLabel, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(10) })
        root.addView(stateRow, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { gravity = Gravity.CENTER_HORIZONTAL })
        root.gap(24)

        // Botão principal
        val size = dp(220)
        askButton = Button(this).apply {
            text = "PERGUNTAR"
            isAllCaps = false
            setTextColor(accentText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            letterSpacing = 0.06f
            background = ripple(GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }, Color.argb(80, 0, 0, 0))
            elevation = dp(8).toFloat()
            stateListAnimator = null
            contentDescription = "Perguntar. Toque e depois fale."
            setOnClickListener { ensureStartedThen { AssistantService.wake(this@MainActivity) } }
        }
        val askFrame = FrameLayout(this)
        askFrame.addView(askButton, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
        root.addView(askFrame, LinearLayout.LayoutParams(MATCH_PARENT, size + dp(16)))
        askHint = label("Toque, espere o sinal e faça a pergunta.\nTambém pode tocar na haste dos óculos.", 15f, muted).apply { gravity = Gravity.CENTER }
        root.addView(askHint, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.gap(20)

        // Última resposta
        answerText = label("—", 19f).apply { accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }
        root.addView(cardView("Última resposta", answerText))
        root.gap(12)

        // Iniciar / parar
        startStop = secondaryButton("Iniciar Smart Vision") {
            if (AssistantService.instance != null) AssistantService.stop(this) else ensureStartedThen { }
        }
        root.addView(startStop, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.gap(12)

        // Dispositivo
        deviceText = label("", 16f)
        root.addView(cardView("Dispositivo", deviceText))
        root.gap(12)

        // Registo
        logText = label("Sem actividade.", 13f, muted).apply { typeface = Typeface.MONOSPACE }
        root.addView(cardView("Registo", logText))
        root.gap(12)

        // Configuração (recolhida)
        settingsBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val proxy = field("Servidor intermediário (opcional)", prefs.proxyUrl)
        val key = field("Chave OpenAI (sk-…)", prefs.apiKey, secret = true)
        val model = field("Modelo", prefs.model)
        listOf(key, model, proxy).forEach {
            settingsBody.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }
        settingsBody.addView(Button(this).apply {
            text = "Guardar"
            isAllCaps = false
            setTextColor(accentText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            background = ripple(rounded(accent, 14), Color.argb(80, 0, 0, 0))
            stateListAnimator = null
            minHeight = dp(52)
            setOnClickListener {
                prefs.apiKey = key.text.toString()
                prefs.model = model.text.toString()
                prefs.proxyUrl = proxy.text.toString()
                text = "Guardado ✓"
                announceForAccessibility("Configuração guardada")
                postDelayed({ text = "Guardar" }, 2000)
            }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        settingsBody.addView(View(this), LinearLayout.LayoutParams(1, dp(10)))
        settingsBody.addView(secondaryButton("Diagnóstico dos óculos (30 s)") { runProbe() },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val settingsToggle = secondaryButton(settingsTitle(false)) {}
        settingsToggle.setOnClickListener {
            val open = settingsBody.visibility != View.VISIBLE
            settingsBody.visibility = if (open) View.VISIBLE else View.GONE
            settingsToggle.text = settingsTitle(open)
        }
        root.addView(settingsToggle, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(settingsBody, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        if (prefs.apiKey.isBlank() && prefs.proxyUrl.isBlank()) {
            settingsBody.visibility = View.VISIBLE
            settingsToggle.text = settingsTitle(true)
        }

        setContentView(ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true; addView(root) })

        // Actualização contínua do ecrã
        scope.launch {
            val ticker = flow { while (true) { emit(Unit); delay(1500) } }
            combine(AssistantService.state, AssistantService.log, AssistantService.lastAnswer, ticker) { s, log, a, _ ->
                Triple(s, log, a)
            }.collect { (s, log, a) -> render(s, log, a) }
        }
    }

    private fun settingsTitle(open: Boolean) = if (open) "Configuração  ▴" else "Configuração  ▾"

    private fun render(s: AssistantService.State, log: List<String>, answer: String) {
        val running = AssistantService.instance != null
        val (txt, color) = when {
            !running -> "Parada" to muted
            s == AssistantService.State.LISTENING -> "A ouvir…" to Color.parseColor("#4DA3FF")
            s == AssistantService.State.THINKING -> "A analisar…" to accent
            s == AssistantService.State.SPEAKING -> "A responder" to Color.parseColor("#3DDC84")
            else -> "Em silêncio · pronta" to Color.parseColor("#3DDC84")
        }
        stateLabel.text = txt
        (stateDot.background as GradientDrawable).setColor(color)
        startStop.text = if (running) "Parar Smart Vision" else "Iniciar Smart Vision"
        askButton.alpha = if (s == AssistantService.State.IDLE) 1f else 0.75f
        if (answer.isNotBlank()) answerText.text = answer
        deviceText.text = deviceSummary()
        logText.text = if (log.isEmpty()) "Sem actividade." else log.joinToString("\n")
    }

    /** Óculos reconhecidos e dispositivos emparelhados. */
    @SuppressLint("MissingPermission")
    private fun deviceSummary(): String {
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            return "Permissão Bluetooth ainda não concedida — toque em Iniciar."
        }
        val g = GlassesRegistry.detect(this)?.displayName
        val bonded = runCatching {
            getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter?.bondedDevices
                ?.mapNotNull { it.name }.orEmpty()
        }.getOrDefault(emptyList())
        return (if (g != null) "Óculos: $g" else "Óculos: nenhum reconhecido\nFunciona na mesma só com o telemóvel.") +
            "\nEmparelhados: ${if (bonded.isEmpty()) "nenhum" else bonded.joinToString(", ")}"
    }

    // ---------- permissões e arranque ----------
    private var pending: (() -> Unit)? = null

    private fun ensureStartedThen(action: () -> Unit) {
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            pending = action
            requestPermissions(missing.toTypedArray(), 1)
            return
        }
        if (AssistantService.instance == null) AssistantService.start(this)
        action()
    }

    override fun onRequestPermissionsResult(requestCode: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            if (AssistantService.instance == null) AssistantService.start(this)
            pending?.invoke()
        } else {
            answerText.text = "A Smart Vision precisa do microfone para funcionar."
        }
        pending = null
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun runProbe() {
        val probe = BleProbe(this)
        val dev = runCatching { probe.bondedDevices() }.getOrDefault(emptyList())
            .firstOrNull { XkOneProAdapter.matches(it.name) }
        if (dev == null) {
            answerText.text = "XK one Pro não encontrado entre os dispositivos emparelhados."
            return
        }
        answerText.text = "A observar ${dev.name} durante 30 s. Prima cada botão uma vez, com pausas."
        scope.launch {
            val file = probe.probe(dev)
            answerText.text = "Registo gravado em:\n${file.absolutePath}"
        }
    }
}
