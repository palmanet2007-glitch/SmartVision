package pt.palma.smartvision.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.util.Log
import android.app.Service
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import pt.palma.smartvision.MainActivity
import pt.palma.smartvision.ai.IntentRouter
import pt.palma.smartvision.ai.OfflineOcrImpl
import pt.palma.smartvision.ai.Prompts
import pt.palma.smartvision.ai.UserIntent
import pt.palma.smartvision.ai.VisionClient
import pt.palma.smartvision.glasses.GenericAudioGlassesAdapter
import pt.palma.smartvision.glasses.GlassesAdapter
import pt.palma.smartvision.glasses.GlassesEvent
import pt.palma.smartvision.glasses.GlassesRegistry
import pt.palma.smartvision.glasses.PhoneCameraSource
import pt.palma.smartvision.nav.LocationHelper
import pt.palma.smartvision.voice.AudioRouting
import pt.palma.smartvision.voice.SpeechInput
import pt.palma.smartvision.voice.SpeechOutput

/**
 * Núcleo da Smart Vision: serviço em primeiro plano, silencioso por defeito.
 *
 * Máquina de estados (uma interacção de cada vez):
 *   IDLE --wake--> LISTENING --frase--> THINKING --resposta--> SPEAKING --> IDLE
 *   Qualquer wake durante THINKING/SPEAKING = interromper e voltar a IDLE.
 *
 * Nenhuma câmara, microfone ou rede é usada em IDLE.
 */
class AssistantService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Ui.Main)

    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    private lateinit var prefs: Prefs
    private lateinit var speechIn: SpeechInput
    private lateinit var speechOut: SpeechOutput
    private lateinit var audio: AudioRouting
    private lateinit var camera: PhoneCameraSource
    private lateinit var location: LocationHelper
    private val ocr = OfflineOcrImpl()
    private var glasses: GlassesAdapter? = null
    private var current: Job? = null
    private var lastAnswer: String = ""

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        speechIn = SpeechInput(this)
        speechOut = SpeechOutput(this).also { it.rate = prefs.speechRate }
        audio = AudioRouting(this)
        camera = PhoneCameraSource(this)
        location = LocationHelper(this)
        startInForeground()
        instance = this

        scope.launch {
            glasses = GlassesRegistry.detect(this@AssistantService)
            val g = glasses ?: return@launch
            g.connect()
            g.events.collect { ev ->
                when (ev) {
                    GlassesEvent.Wake -> onWake()
                    GlassesEvent.Cancel -> interrupt()
                    is GlassesEvent.Connection -> Log.i(TAG, "Óculos ligados=${ev.connected}")
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_WAKE) onWake()
        return START_STICKY
    }

    /** Ponto único de activação: botão dos óculos, botão no ecrã ou (futuro) palavra "Smart". */
    fun onWake() {
        if (_state.value != State.IDLE) { interrupt(); return }
        current = scope.launch { runInteraction() }
    }

    private fun interrupt() {
        current?.cancel()
        speechOut.stop()
        audio.closeGlassesMic()
        _state.value = State.IDLE
    }

    private fun log(msg: String) {
        Log.i(TAG, msg)
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ROOT).format(java.util.Date())
        _log.value = (_log.value + "$t  $msg").takeLast(12)
    }

    private suspend fun runInteraction() {
        try {
            log("Pedido recebido (dispositivo: ${glasses?.displayName ?: "só telemóvel"}).")
            _state.value = State.LISTENING
            val micOnGlasses = audio.openGlassesMic()
            log(if (micOnGlasses) "A ouvir pelo microfone dos óculos…" else "A ouvir pelo microfone do telemóvel…")
            audio.earconListening()
            val heard = speechIn.listenOnce()
            if (micOnGlasses) audio.closeGlassesMic()
            if (heard.isNullOrBlank()) {
                val why = speechIn.describeError(speechIn.lastError)
                log("Falhou a escuta: $why.")
                audio.earconError()
                speechOut.speak("Não percebi: $why.")
                return
            }

            val utterance = IntentRouter.stripWakeWord(heard)
            val intent = IntentRouter.route(utterance)
            _lastHeard.value = utterance
            log("Ouvi: \"$utterance\" → $intent")

            _state.value = State.THINKING
            val answer: String? = when (intent) {
                UserIntent.STOP -> null
                UserIntent.REPEAT -> lastAnswer.ifBlank { "Não tenho nada para repetir." }
                UserIntent.WHERE_AM_I -> location.describe()
                else -> answerWithVision(intent, utterance)
            }
            if (answer != null) {
                lastAnswer = answer
                _lastAnswer.value = answer
                _state.value = State.SPEAKING
                speechOut.speak(answer)
                log("Resposta falada.")
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            log("Interrompido.")
            throw e
        } catch (e: Exception) {
            log("Erro inesperado: ${e.javaClass.simpleName} ${e.message ?: ""}")
            runCatching { speechOut.speak("Ocorreu um erro.") }
        } finally {
            audio.closeGlassesMic()
            (glasses as? GenericAudioGlassesAdapter)?.reclaimMediaButtons()
            _state.value = State.IDLE
        }
    }

    private suspend fun answerWithVision(intent: UserIntent, utterance: String): String {
        log("A tirar fotografia…")
        val frame: Bitmap = glasses?.takeIf { it.capabilities.camera }?.captureFrame()
            ?: camera.capture()
            ?: run { log("Câmara falhou (permissão ou câmara ocupada)."); return "Não consigo usar a câmara." }
        log("Fotografia OK (${frame.width}×${frame.height}).")

        val client = VisionClient(prefs.apiKey, prefs.proxyUrl, prefs.model)
        var failure: String? = null
        if (client.isConfigured) {
            log("A perguntar à OpenAI (modelo ${prefs.model})…")
            val t0 = System.currentTimeMillis()
            val ok = runCatching { client.ask(Prompts.forIntent(intent, utterance), frame) }
            ok.getOrNull()?.let {
                log("Resposta em ${(System.currentTimeMillis() - t0) / 100 / 10.0} s.")
                return it
            }
            val e = ok.exceptionOrNull()
            failure = if (e is pt.palma.smartvision.ai.VisionException) e.message
            else "Sem ligação à internet ou ao serviço (${e?.javaClass?.simpleName})."
            log("Falhou: $failure")
        } else {
            log("Serviço de visão não configurado (falta a chave).")
        }
        // Recurso offline: leitura de texto local.
        val text = ocr.read(frame)
        return when {
            text != null -> "${failure ?: "Sem ligação."} Texto visível: $text"
            failure != null -> failure
            else -> "Serviço de visão não configurado. Introduza a chave na aplicação."
        }
    }

    private fun startInForeground() {
        val nm = requireNotNull(getSystemService(NotificationManager::class.java))
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Smart Vision activa", NotificationManager.IMPORTANCE_LOW),
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        val wake = PendingIntent.getService(
            this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_WAKE),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Smart Vision em silêncio")
            .setContentText("Toque nos óculos para perguntar.")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Perguntar", wake).build())
            .setOngoing(true)
            .build()
        // Só se declaram os tipos cujas permissões estão concedidas (Android 14+ exige-o).
        fun granted(p: String) = checkSelfPermission(p) == android.content.pm.PackageManager.PERMISSION_GRANTED
        var types = 0
        if (granted(android.Manifest.permission.RECORD_AUDIO)) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (granted(android.Manifest.permission.CAMERA)) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        if (granted(android.Manifest.permission.ACCESS_FINE_LOCATION)) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        startForeground(NOTIF_ID, n, types)
    }

    override fun onDestroy() {
        interrupt()
        glasses?.disconnect()
        camera.stop()
        speechOut.shutdown()
        instance = null
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "SmartVision"
        private const val CHANNEL = "smartvision"
        private const val NOTIF_ID = 42
        const val ACTION_WAKE = "pt.palma.smartvision.WAKE"

        @Volatile var instance: AssistantService? = null
            private set

        private val _state = MutableStateFlow(State.IDLE)
        val state: StateFlow<State> = _state
        private val _lastHeard = MutableStateFlow("")
        val lastHeard: StateFlow<String> = _lastHeard
        private val _log = MutableStateFlow<List<String>>(emptyList())
        val log: StateFlow<List<String>> = _log
        private val _lastAnswer = MutableStateFlow("")
        val lastAnswer: StateFlow<String> = _lastAnswer

        fun start(context: Context) {
            context.startForegroundService(Intent(context, AssistantService::class.java))
        }
        fun stop(context: Context) {
            context.stopService(Intent(context, AssistantService::class.java))
        }
        fun wake(context: Context) {
            context.startForegroundService(
                Intent(context, AssistantService::class.java).setAction(ACTION_WAKE),
            )
        }
    }
}
