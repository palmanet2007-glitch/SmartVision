package pt.palma.smartvision.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import pt.palma.smartvision.core.Ui
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * Reconhecimento de fala do sistema (pt-PT), preferencialmente no dispositivo.
 * Uma escuta = uma frase. Não há escuta contínua.
 */
class SpeechInput(private val context: Context) {

    /** Último código de erro do reconhecedor (0 = nenhum), para diagnóstico. */
    var lastError: Int = 0
        private set

    fun describeError(code: Int): String = when (code) {
        -1 -> "reconhecimento de voz indisponível neste telemóvel"
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "não ouvi nenhuma frase"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "sem permissão de microfone"
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "reconhecimento de voz sem rede"
        SpeechRecognizer.ERROR_AUDIO -> "erro no microfone"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "reconhecedor ocupado"
        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "português não instalado no reconhecimento de voz"
        else -> "erro de reconhecimento ($code)"
    }

    suspend fun listenOnce(language: String = "pt-PT"): String? = withContext(Ui.Main) {
        lastError = 0
        if (!SpeechRecognizer.isRecognitionAvailable(context)) { lastError = -1; return@withContext null }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        try {
            suspendCancellableCoroutine<String?> { cont ->
                var done = false
                fun finish(text: String?) {
                    if (!done) { done = true; cont.resume(text) }
                }
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onResults(results: Bundle?) {
                        finish(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
                    }
                    override fun onError(error: Int) { lastError = error; finish(null) }
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                cont.invokeOnCancellation { recognizer.cancel() }
                recognizer.startListening(intent)
            }
        } finally {
            recognizer.destroy()
        }
    }
}
