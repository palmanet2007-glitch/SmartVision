plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.palma.smartvision"
    compileSdk = 35

    defaultConfig {
        applicationId = "pt.palma.smartvision"
        minSdk = 31          // Android 12: BLUETOOTH_CONNECT, setCommunicationDevice
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }

    // full: com OCR offline (ML Kit). lite: só plataforma Android, sem bibliotecas Google.
    flavorDimensions += "ocr"
    productFlavors {
        create("full") { dimension = "ocr" }
        create("lite") { dimension = "ocr"; versionNameSuffix = "-lite" }
    }

    // Chave fixa (de testes) para que cada nova versão se instale por cima da anterior.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.9.0")
    // OCR local (offline) — modelo latino embebido; só na variante "full"
    "fullImplementation"("com.google.mlkit:text-recognition:16.0.1")
}
